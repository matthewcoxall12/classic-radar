# ClassicsGo event discovery

The production discovery runner is a bounded GitHub Actions job. It runs at minute 17 every six hours, on manual dispatch, and once after a change reaches `main`. It does not use Supabase Cron or Vercel Cron.

## Trust boundary

The workflow requests a short-lived GitHub OIDC token with audience `classicsgo-ingest`. The `ingest-events` Supabase Edge Function verifies the issuer, audience, repository owner ID, repository, workflow file, event type and `refs/heads/main` before returning source configuration or accepting a batch. There is no Supabase secret in GitHub or Vercel. The Edge Function reads Supabase's built-in `SUPABASE_SECRET_KEYS` dictionary and sends the selected secret on the `apikey` header only.

For production runs, the runner first requests the active source catalogue through that authenticated Edge endpoint. The migration seeds the initial catalogue; administrator changes to source URL, format, frequency, review status or active status therefore take effect on the next run. Local dry-runs intentionally use the checked-in catalogue and cannot read production configuration.

## Discovery layers

- Rotating UK-wide and Europe-wide official source catalogue
- Bounded, robots-aware link and sitemap traversal
- JSON-LD Event, HTML Microdata and OpenGraph extraction
- RSS/Atom and ICS calendar ingestion, including bounded recurring ICS occurrences
- `chrono-node` multilingual date parsing
- Fuse.js title matching plus geolib coordinate deduplication
- Free UK postcode coordinate enrichment through the postcodes.io bulk endpoint
- Optional Firecrawl search, JS-rendered scrape, map and deep crawl with automatic proxy selection
- Legacy-optional Google Programmable Search adapter for existing customers only; it is not a core dependency

Search-only sources such as public Facebook and Eventbrite listings require review unless independent sources corroborate the event. The crawler never logs in, reads private content, or bypasses a site's robots policy.

## Resource limits

Each run fairly rotates due source coverage so lower-priority regional sources cannot be permanently starved by the per-run cap, limits pages and candidates, sends batches of 40, stores at most a 1,000-character raw excerpt, removes raw observations after 90 days, and removes completed operational run logs after 180 days. Canonical events and source citations remain. Source health is recorded even when a crawl finds no candidates. If post-start ingestion fails, the runner makes a best-effort final call that marks the run failed instead of leaving it indefinitely in progress.

## Local validation

```sh
npm run test:discovery
npm run discover -- --dry-run --max-sources=2 --max-pages=2
```

The non-dry runner intentionally works only inside the trusted GitHub workflow because it needs the GitHub OIDC request environment.
