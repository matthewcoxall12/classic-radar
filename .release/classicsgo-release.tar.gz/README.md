# ClassicsGo

ClassicsGo is a production Next.js application for finding classic-car shows, club meets, autojumbles, museum days, road runs and historic-motorsport events across the United Kingdom and Europe.

## Production architecture

- Next.js 16 on Vercel
- Google OAuth through Supabase Auth
- Supabase Postgres with Row Level Security
- GitHub Actions event discovery every six hours
- Supabase Edge Function ingestion authenticated with GitHub OIDC
- No hardcoded or demo events
- No Supabase Cron, Vercel Cron, long-lived CI database key, or email/password dependency

## Commands

```sh
npm ci
npm run typecheck
npm run lint
npm run build
npm run test:discovery
```

A safe local discovery sample does not write to the database:

```sh
npm run discover -- --dry-run --max-sources=2 --max-pages=2
```

See [docs/event-discovery.md](docs/event-discovery.md) for extraction, scheduling, security and retention details.

## Public configuration

The website needs `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`. Optional discovery services are configured only as GitHub Actions secrets; the core direct-source pipeline works without them.
